Corner Deli Caller Popup - 3CX v20 CFD source project

Purpose
  1. Check which deli extension is currently available and not in a call.
  2. Notify Corner Ops with Line 1 (95), Line 2 (96), or waiting status.
  3. Transfer the caller to queue 90. The queue holds the caller when both
     extensions are busy.
  4. If any check or web request fails, the Error Handler still transfers to
     queue 90.

Before building
  1. Open CornerDeliCallerPopup.cfdproj in 3CX Call Flow Designer v20.
  2. Select Main.flow, then its Variables collection.
  3. Replace PASTE_EXISTING_CORNEROPS_CRM_SECRET_HERE in ApiSecret with the
     same secret already configured in the CornerOps CRM template.
  4. Confirm each notifyCornerOps request uses GET, timeout 2 seconds, and the
     header x-corner-ops-crm-secret with value callflow$.ApiSecret.
  5. Confirm every Transfer component targets queue 90.
  6. Build > Build All. An extension may be left blank for DID-only use.

After building
  Upload the generated Release ZIP to 3CX as a Call Flow App. Route only the
  deli DID to this app. Do not alter queue 90 or extensions 95 and 96.

Call path
  Deli DID -> check ext 95/96 -> timestamped Corner Ops popup -> queue 90
  Queue 90 enforces agent login, rings the available logged-in extension, or
  holds until one becomes available.

Important
  The popup line is the availability result immediately before the transfer.
  Queue 90 still controls the actual ring and answer after the CFD transfers it.
