Corner Deli Caller Popup - 3CX v20 CFD source project

Purpose
  1. Notify Corner Ops that a caller entered the deli route.
  2. Immediately blind-transfer the caller to existing queue 90.
  3. If the web request fails, the Error Handler still transfers to queue 90.

Before building
  1. Open CornerDeliCallerPopup.cfdproj in 3CX Call Flow Designer v20.
  2. Select Main.flow, then its Variables collection.
  3. Replace PASTE_EXISTING_CORNEROPS_CRM_SECRET_HERE in ApiSecret with the
     same secret already configured in the CornerOps CRM template.
  4. Confirm notifyCornerOps uses GET, timeout 2 seconds, and the header
     x-corner-ops-crm-secret with value callflow$.ApiSecret.
  5. Confirm both Transfer components target queue 90.
  6. Build > Build All. An extension may be left blank for DID-only use.

After building
  Upload the generated Release ZIP to 3CX as a Call Flow App. Route only the
  deli DID to this app. Do not alter queue 90 or extensions 95 and 96.

Call path
  Deli DID -> this CFD app -> Corner Ops popup -> queue 90 -> ext 95/ext 96
